//1. Crie um modulo de calculadora, exportando as 4 operações básicas: somar, subtrair, dividir, multiplicar
//- Dentro de outro arquivo, importar as funções e executar as operações

const somar = (n1, n2) => n1 + n2;

const subtrair = (n1, n2) => n1 - n2;

const dividir = (n1, n2) => n1 / n2;

const multiplicar = (n1, n2) => n1 * n2;

module.exports = {
    somar,
    subtrair,
    dividir,
    multiplicar
}



