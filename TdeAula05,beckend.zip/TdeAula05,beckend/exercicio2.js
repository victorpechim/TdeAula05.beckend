const createRandomUser = () => {
    const userId = faker.string.uuid()
    const username = faker.internet.userName()
    const email = faker.internet.email()
    const avatar = faker.image.avatar()
    const password = faker.internet.password()
    const birthdate = faker.date.birthdate()
    const registeredAt = faker.date.past()
}

const { faker } = require('@faker-js/faker')

function randomInformUser() {
    const name = faker.person.fullName()
    const email = faker.internet.email()
    const birthdate = faker.date.birthdate()

    console.log(name)
    console.log(email)
    console.log(birthdate)
}

randomInformUser();