const calculadora = require("./exercicio1")

console.log(calculadora.somar(2, 3));
console.log(calculadora.subtrair(2, 3));
console.log(calculadora.dividir(2, 3));
console.log(calculadora.multiplicar(2, 3));